import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import AnnouncementForm from '../components/annonces/AnnonceForm';
import { annonceAPI } from '../utils/api';
import Loading from '../components/common/Loading';

const AnnonceFormPage = () => {
  const [announcement, setAnnouncement] = useState(null);
  const [loading, setLoading] = useState(true);
  const { id } = useParams();
  const navigate = useNavigate();
  const isEditing = !!id;

  useEffect(() => {
    if (isEditing) {
      const fetchAnnonce = async () => {
        try {
          const response = await annonceAPI.getById(id);
          // CORRECTION: On accède directement à 'annonce'
          setAnnouncement(response.data.annonce);
        } catch (error) {
          console.error("Erreur lors de la récupération de l'annonce:", error);
        } finally {
          setLoading(false);
        }
      };
      fetchAnnonce();
    } else {
      setLoading(false);
    }
  }, [id, isEditing]);

  const handleSubmit = async (formData) => {
    try {
      if (isEditing) {
        const response = await annonceAPI.update(id, formData);
        // CORRECTION: On accède directement à 'annonce'
        const updatedAnnonce = response.data.annonce;
        navigate(`/annonces/${updatedAnnonce._id}`);
      } else {
        const response = await annonceAPI.create(formData);
        // CORRECTION: On accède directement à 'annonce'
        const newAnnonce = response.data.annonce;
        navigate(`/annonces/${newAnnonce._id}`);
      }
    } catch (error) {
      console.error("Erreur lors de la soumission du formulaire:", error);
    }
  };

  const handleCancel = () => {
    navigate(isEditing ? `/annonces/${id}` : '/dashboard');
  };

  if (loading && isEditing) {
    return <Loading />;
  }

  return (
    <AnnouncementForm 
      announcement={announcement}
      onSubmit={handleSubmit}
      onCancel={handleCancel}
    />
  );
};

export default AnnonceFormPage;