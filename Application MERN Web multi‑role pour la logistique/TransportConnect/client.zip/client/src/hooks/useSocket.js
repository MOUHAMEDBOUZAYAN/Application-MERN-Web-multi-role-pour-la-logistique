export { useSocket } from '../context/SocketContext';
